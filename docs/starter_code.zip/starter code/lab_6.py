import numpy as np
import math
from typing import List, Dict

from qiskit import *
from qiskit.circuit.library.standard_gates import MCXGate

def diffuser(n: int) -> QuantumCircuit:
    """Returns QuantumCircuit that rotates the state around |s>
    Args:
        n: How many qubits the diffuser should process"""
    qc = QuantumCircuit(n)

    # Map |s> -> |00..0> ->|11..1> 
    
    # Rotate around |0>
    
    # |11..1> -> |00..0> -> |s>


    return qc

def grover() -> QuantumCircuit:
    """Returns a Grover circuit to solve the below mystery_oracle
       Make sure to NOT add measruments here, as the tests already do so"""
    pass 

# DO NOT MODIFY THIS FUNCTION
def mystery_oracle():
    """Returns QuantumCircuit implementing some 3->1 bit function
       Input are provided in bits 0-2 and the result is placed on
       bit 5. Bits 3-4 are used as temporary "ancilla bits"
    """
    oracle = QuantumCircuit(6)
    
    # t1
    oracle.cx(0,3)
    oracle.cx(1,3)

    # t2
    oracle.x({0,2})
    oracle.cx(0,4)
    oracle.cx(2,4)
    oracle.x({0,2})

    # o
    gate = MCXGate(3, ctrl_state=0b111)
    oracle.append(gate,{5,4,3,1})

    # uncompute t2
    oracle.x({0,2})
    oracle.cx(2,4)
    oracle.cx(0,4)
    oracle.x({0,2})

    # uncompute t1
    oracle.cx(1,3)
    oracle.cx(0,3)


    return oracle