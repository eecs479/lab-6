import numpy as np
import math
import unittest
from typing import Dict, List

# Qiskit core
from qiskit import QuantumCircuit, transpile
from qiskit.visualization import plot_histogram
from qiskit.quantum_info import Statevector

# Qiskit circuit elements
from qiskit.circuit import QuantumCircuit
from qiskit.circuit.library import GroverOperator, PhaseOracle, QFT
from qiskit.circuit.library.standard_gates import SXGate, MCXGate

# Qiskit Aer for simulation
from qiskit_aer import AerSimulator

import lab_6


def correct_diffuser_matrix(n):
    N = 2**n
    s = np.array([1 / np.sqrt(N)] * N)
    # diffuser is described by 2*|s><s|-1
    # (our implementation adds a -1 phase for simplicity)
    matrix = -1 * (2 * np.outer(s, s) - np.identity(N))
    return matrix


class TestLab6(unittest.TestCase):

    def check_diffuser(self, diffuser, n):
        # generate device under test
        dut = QuantumCircuit(n)
        dut.append(diffuser, range(n))
        dut.save_unitary()

        sim = AerSimulator()
        compiled_dut = transpile(dut, sim)
        unitary = np.asarray(sim.run(compiled_dut).result().get_unitary())

        correct = correct_diffuser_matrix(n)
        self.assertTrue(np.allclose(unitary, correct))

    def test_diffuser(self):
        for i in range(2, 6):
            diffuser = lab_6.diffuser(i)
            self.check_diffuser(diffuser, i)

    def test_diffuser_1bit(self):
        diffuser = lab_6.diffuser(1)
        self.check_diffuser(diffuser, 1)

    def test_grover(self):
        dut = QuantumCircuit(6, 3)
        dut.append(lab_6.grover(), range(6), range(3))
        dut.measure(range(3), range(3))

        sim = AerSimulator()
        compiled_dut = transpile(dut, sim)
        counts = sim.run(compiled_dut).result().get_counts()
        most_common = max(counts, key=counts.get)
        self.assertEqual(
            most_common, "110"
        )  # super-secret code... avert your eyes!


if __name__ == "__main__":
    unittest.main()
